# Z-GAME HUB — Windows

Edição nativa para Windows 10/11 x64, release 1.0.1. Esta edição não usa a camada de jogos Linux: não instala nem executa Proton, Wine, Flatpak, Lutris ou Bottles.

## O que faz

- Descobre bibliotecas Steam Windows a partir de caminhos usuais e chaves do Registro, lê bibliotecas extras em `libraryfolders.vdf` e abre jogos por `steam://rungameid/<appid>`.
- Lê metadados Heroic em `%APPDATA%\heroic` e `%USERPROFILE%\.config\heroic` / `legendary`, e delega o lançamento ao Heroic para Windows pelo protocolo `heroic://launch`.
- Lê manifests `.item` locais do Epic Games Launcher e lança pela ativação de protocolo `com.epicgames.launcher`.
- Lê IDs e diretórios de instalação Ubisoft Connect no Registro do Windows e solicita a abertura por `uplay://launch/<id>/0`.
- Permite cadastrar jogos e aplicativos manualmente; executáveis `.exe` e atalhos `.lnk` podem ser iniciados diretamente.
- Detecta RetroArch e cores `*_libretro.dll` nos diretórios comuns do Windows.
- Mantém o catálogo local SQLite e a interface da biblioteca.

Os jogos continuam vinculados às contas e aos launchers do usuário. O HUB não baixa jogos, ROMs nem conteúdo de conta.

## O que acompanha o pacote

O ZIP produzido pelo build inclui o executável do HUB, dependências Qt/QML encontradas por `windeployqt`, o driver SQLite do Qt e avisos de terceiros. O Microsoft Visual C++ Runtime x64 pode ser exigido no computador de destino; `install-launchers-windows.bat` oferece instalá-lo via WinGet. Steam, Heroic, Epic Games Launcher, Ubisoft Connect e RetroArch são programas de terceiros e não são embutidos no HUB. O mesmo script pode instalá-los por WinGet, pedindo confirmação separadamente para cada aplicativo. Ele não baixa jogos ou ROMs. Antes de redistribuir publicamente um build Qt, revise os termos aplicáveis descritos em `THIRD-PARTY-NOTICES.txt`.

## Preparar dependências, compilar e empacotar

Extraia o ZIP e execute `scripts\setup-windows.bat` a partir da pasta do projeto. Se o terminal já estiver em `scripts`, rode `setup-windows.bat` diretamente:

```bat
scripts\setup-windows.bat
```

O script verifica Qt 6.8.3 MSVC x64, Visual Studio 2022 C++ Build Tools, CMake, Ninja e Python. Se algo estiver faltando, tenta instalar pelo WinGet ou usa `aqtinstall` para obter o kit Qt base, sem passar nomes de módulos extras inválidos. Isso pode baixar vários gigabytes e pode pedir elevação/UAC. Também verifica os componentes Qt Core, Gui, QML, Quick, SQL e SQLite antes de compilar. O `build-windows.bat` abre o script de preparação se o Qt não for localizado ou estiver incompleto.

Para compilar sem preparar dependências novamente, use o **x64 Native Tools Command Prompt for VS 2022** e rode:

```bat
scripts\build-windows.bat
```

O executável intermediário fica em `build\windows\z-game-hub.exe`; a pasta implantada e o ZIP portátil ficam em `dist\windows\`. Se o Inno Setup (`ISCC.exe`) estiver no `PATH`, o build também gera `Z-GAME-HUB-Windows-Setup-v1.0.1.exe`.

Para instalar programas opcionais depois, execute `install-launchers.bat` na pasta instalada (ou `scripts\install-launchers-windows.bat` no projeto). O script usa WinGet e pergunta antes de instalar o runtime MSVC, Steam, Heroic, Epic Games Launcher, Ubisoft Connect ou RetroArch.

## Limites e validação

Esta é uma primeira portabilidade e precisa ser compilada/testada em Windows. A leitura Epic usa manifests locais `.item`; o lançamento segue o protocolo de ativação documentado pela Epic. A descoberta Ubisoft depende das entradas `Launcher\Installs` e de IDs numéricos; o URI `uplay://` é comportamento do cliente que precisa de teste em instalações reais. Heroic e Steam também exigem que seus respectivos protocolos estejam registrados pelos clientes.

Os leitores Linux foram separados da edição Windows: esta variante não usa Proton, Flatpak, Lutris ou Bottles.
