# Z-GAME HUB — Windows

Edição nativa para Windows 10/11 x64, release **1.1.0**. Esta edição não usa a camada de jogos Linux: não instala nem executa Proton, Wine, Flatpak, Lutris ou Bottles.

## O que faz

- Descobre bibliotecas Steam Windows a partir de caminhos usuais e chaves do Registro, lê bibliotecas extras em `libraryfolders.vdf` e abre jogos por `steam://rungameid/<appid>`.
- Lê metadados Heroic em `%APPDATA%\heroic` e `%USERPROFILE%\.config\heroic` / `legendary`, e delega o lançamento ao Heroic para Windows pelo protocolo `heroic://launch`.
- Lê manifests `.item` locais do Epic Games Launcher e lança pela ativação de protocolo `com.epicgames.launcher`.
- Lê IDs e diretórios de instalação Ubisoft Connect no Registro do Windows e solicita a abertura por `uplay://launch/<id>/0`.
- Permite cadastrar jogos e aplicativos manualmente; executáveis `.exe` e atalhos `.lnk` podem ser iniciados diretamente.
- Detecta RetroArch e cores `*_libretro.dll` nos diretórios comuns do Windows.
- Mantém o catálogo local SQLite e a interface da biblioteca.
- Inclui a tela **ROMs e BIOS**, que pesquisa recursivamente uma pasta escolhida, reconhece formatos comuns de ROM/imagem e mostra alguns nomes conhecidos de BIOS/firmware ou arquivos encontrados em pastas `BIOS`, `Firmware` e `System`. ROMs podem ser adicionadas à biblioteca e iniciadas com um emulador configurado por plataforma. Arquivos de suporte são apenas listados e não são importados como jogos.
- Inclui a tela **Quiver**, com links para o launcher Quiver, suas releases, o catálogo comunitário legado e o canal atual de submissões.

O Quiver Launcher é um aplicativo separado e não está embutido no Z-GAME HUB. Depois de baixar e extrair o Quiver, use **Adicionar Quiver instalado à biblioteca** na tela Quiver e selecione `QuiverLauncher.exe` para poder iniciá-lo pelo HUB. O [repositório do catálogo comunitário legado](https://github.com/tgeorgiadis/quiver-community-app-catalog) informa que está descontinuado e não aceita novas submissões. As listas antigas permanecem publicadas para instalações compatíveis; novas sugestões devem ser feitas em [quiverlauncher.com/submit](https://quiverlauncher.com/submit). O botão de download na tela Quiver abre as releases oficiais do [Quiver Launcher](https://github.com/tgeorgiadis/quiver-launcher/releases/latest).

URLs Git fornecidas para consulta ou clonagem dos projetos:

```text
https://github.com/tgeorgiadis/quiver-community-app-catalog.git
https://github.com/tgeorgiadis/quiver-launcher.git
```

A busca de ROMs é **local**. O HUB não procura nem baixa ROMs, BIOS, firmware, jogos ou arquivos de conta. A detecção de BIOS é uma referência baseada em nomes e pastas comuns; ela não confirma que todos os arquivos exigidos por um emulador estejam presentes ou sejam compatíveis. O suporte a `.zip`, `.7z` e `.rar` depende do emulador/core configurado; o HUB não extrai arquivos compactados. Use somente jogos, ROMs, BIOS e outros arquivos que você tem direito de usar.

## O que acompanha o pacote

O ZIP produzido pelo build inclui o executável do HUB, dependências Qt/QML encontradas por `windeployqt`, o driver SQLite do Qt e avisos de terceiros. O Microsoft Visual C++ Runtime x64 pode ser exigido no computador de destino; `install-launchers-windows.bat` oferece instalá-lo via WinGet. Steam, Heroic, Epic Games Launcher, Ubisoft Connect e RetroArch são programas de terceiros e não são embutidos no HUB. O mesmo script pode instalá-los por WinGet, pedindo confirmação separadamente para cada aplicativo. Ele não baixa jogos ou ROMs. Antes de redistribuir publicamente um build Qt, revise os termos aplicáveis descritos em `THIRD-PARTY-NOTICES.txt`.

## Preparar dependências, compilar e empacotar

Extraia o ZIP e execute `scripts\setup-windows.bat` a partir da pasta do projeto. Se o terminal já estiver em `scripts`, rode `setup-windows.bat` diretamente:

```bat
scripts\setup-windows.bat
```

O script verifica Qt 6.8.3 MSVC x64, Visual Studio 2022 C++ Build Tools, CMake, Ninja e Python. Se algo estiver faltando, tenta instalar pelo WinGet ou usa `aqtinstall` para obter o kit Qt base. Isso pode baixar vários gigabytes e pode pedir elevação/UAC. Também verifica os componentes Qt Core, Gui, QML, Quick, SQL e SQLite antes de compilar. O `build-windows.bat` abre o script de preparação se o Qt não for localizado ou estiver incompleto.

Para compilar sem preparar dependências novamente, use o **x64 Native Tools Command Prompt for VS 2022** e rode:

```bat
scripts\build-windows.bat
```

O executável intermediário fica em `build\windows\z-game-hub.exe`; a pasta implantada e o ZIP portátil ficam em `dist\windows\`. Se o Inno Setup (`ISCC.exe`) estiver no `PATH`, o build também gera `Z-GAME-HUB-Windows-Setup-v1.1.0.exe`.

Para instalar programas opcionais depois, execute `install-launchers.bat` na pasta instalada (ou `scripts\install-launchers-windows.bat` no projeto). O script usa WinGet e pergunta antes de instalar o runtime MSVC, Steam, Heroic, Epic Games Launcher, Ubisoft Connect ou RetroArch.

## Limites e validação

Esta edição Windows precisa ser compilada e testada em Windows. A leitura Epic usa manifests locais `.item`; o lançamento segue o protocolo de ativação documentado pela Epic. A descoberta Ubisoft depende das entradas `Launcher\Installs` e de IDs numéricos; o URI `uplay://` precisa de teste em instalações reais. Heroic e Steam também exigem que seus respectivos protocolos estejam registrados pelos clientes.

O catálogo comunitário Quiver informado pelo usuário é legado/descontinuado. O HUB abre os projetos externos em vez de copiar ou incorporar o código do Quiver. Não há catálogo remoto de ROMs nem download de jogo, BIOS ou firmware.
